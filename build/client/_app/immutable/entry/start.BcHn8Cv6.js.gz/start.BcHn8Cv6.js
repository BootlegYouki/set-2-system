import{l as o,a as r}from"../chunks/B8zd8TXP.js";export{o as load_css,r as start};
